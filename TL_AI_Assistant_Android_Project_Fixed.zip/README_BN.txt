TL AI Assistant — প্রাথমিক Android source project

এটি APK নয়; এটি source project, যেটি build করে APK তৈরি করতে হবে.
পূর্ণ AI model/API এখনও যুক্ত করা হয়নি। এই prototype-এ বাংলা voice input, Settings খোলা এবং file picker-এর প্রাথমিক সুবিধা আছে।
Android-এর অনুমতি ছাড়া ফোনের সব ফাইল নিয়ন্ত্রণ করা যায় না।

GitHub Actions build-এর জন্য পরে .github/workflows/build.yml ফাইল যোগ করতে হবে।
